package model;

public class Attraction {
    private int id;
    private String nom;
    private String parc;
    private double prixBase;
    private String type;
    private String description;

    public Attraction() {}

    public Attraction(String nom, String parc, double prixBase, String type) {
        this.nom = nom;
        this.parc = parc;
        this.prixBase = prixBase;
        this.type = type;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getParc() {
        return parc;
    }

    public double getPrixBase() {
        return prixBase;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setParc(String parc) {
        this.parc = parc;
    }

    public void setPrixBase(double prixBase) {
        this.prixBase = prixBase;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

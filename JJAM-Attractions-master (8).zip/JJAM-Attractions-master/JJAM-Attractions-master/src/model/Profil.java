package model;

public enum Profil {
    ENFANT,
    SENIOR,
    REGULIER;
}

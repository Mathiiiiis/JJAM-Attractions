package model;

public class ClientInvite extends Client {
    @Override
    public double calculerReduction() {
        return 0.0;
    }
}
package dao;

import model.Attraction;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AttractionDAOImpl {

    // Récupérer toutes les attractions
    public List<Attraction> getAllAttractions() {
        List<Attraction> attractions = new ArrayList<>();
        String sql = "SELECT * FROM attractions";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Attraction attraction = new Attraction(
                        rs.getString("nom"),
                        rs.getString("parc"),
                        rs.getDouble("prix_base"),
                        rs.getString("type")
                );
                attractions.add(attraction);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return attractions;
    }

    // ✅ Nouvelle méthode pour obtenir tous les noms de parcs sans doublon
    public List<String> getAllParcsDistinct() {
        Set<String> parcs = new HashSet<>();
        String sql = "SELECT DISTINCT parc FROM attractions";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                parcs.add(rs.getString("parc"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new ArrayList<>(parcs);
    }

    // ✅ Ajout d'une attraction
    public boolean addAttraction(Attraction attraction) {
        String sql = "INSERT INTO attractions (nom, parc, prix_base, type) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, attraction.getNom());
            stmt.setString(2, attraction.getParc());
            stmt.setDouble(3, attraction.getPrixBase());
            stmt.setString(4, attraction.getType());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Récupération de la capacité d'un parc
    public int getCapaciteParc(String parc) {
        String sql = "SELECT capacite FROM parcs WHERE nom = ?";
        int capacite = 0;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, parc);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                capacite = rs.getInt("capacite");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return capacite;
    }

    // ✅ Nombre de réservations existantes pour une date + parc
    public int getNombreReservationsParcDate(String parc, java.time.LocalDate date) {
        String sql = "SELECT COUNT(*) AS total FROM reservations WHERE parc_nom = ? AND date_reservation = ?";
        int reservations = 0;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, parc);
            stmt.setDate(2, java.sql.Date.valueOf(date));
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                reservations = rs.getInt("total");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reservations;
    }
}

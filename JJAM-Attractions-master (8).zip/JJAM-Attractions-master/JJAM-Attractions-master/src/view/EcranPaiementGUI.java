package view;

import model.Client;
import model.Parc;
import view.TicketPanel;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EcranPaiementGUI extends JFrame {
    private JProgressBar progressBar;
    private JLabel messageLabel;
    private Timer timer;
    private int progress = 0;

    private Client client;
    private List<TicketPanel> billets;
    private List<Parc> parcsChoisis;
    private double montantTotal;

    public EcranPaiementGUI(Client client, List<TicketPanel> billets, List<Parc> parcsChoisis, double montantTotal) {
        this.client = client;
        this.billets = billets;
        this.parcsChoisis = parcsChoisis;
        this.montantTotal = montantTotal;

        setTitle("Traitement du Paiement");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        messageLabel = new JLabel("Connexion à la banque...", SwingConstants.CENTER);
        messageLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(messageLabel, BorderLayout.NORTH);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setFont(new Font("SansSerif", Font.PLAIN, 16));
        add(progressBar, BorderLayout.CENTER);

        lancerChargement();
        setVisible(true);
    }

    private void lancerChargement() {
        timer = new Timer(50, e -> {
            progress++;
            progressBar.setValue(progress);

            if (progress == 30) {
                messageLabel.setText("Vérification des fonds...");
            } else if (progress == 60) {
                messageLabel.setText("Validation de la transaction...");
            } else if (progress == 90) {
                messageLabel.setText("Finalisation...");
            }

            if (progress >= 100) {
                timer.stop();
                JOptionPane.showMessageDialog(this, "✅ Paiement effectué avec succès !", "Succès", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new PageConfirmationReservationGUI(client, billets, parcsChoisis, montantTotal).setVisible(true);
            }
        });
        timer.start();
    }
}

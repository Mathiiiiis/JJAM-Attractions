package view;

import dao.ClientDAO;
import model.Client;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class MesAbonnementsPanel extends JPanel {
    private Client client;
    private ClientDAO clientDAO;
    private JLabel abonnementActuelLabel;
    private List<String> options = Arrays.asList("VIP", "SUPER_VITESSE", "PASS_ANNUEL");

    public MesAbonnementsPanel(Client client) {
        this.client = client;
        this.clientDAO = new ClientDAO();

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        initUI();
    }

    private void initUI() {
        JPanel contenu = new JPanel();
        contenu.setLayout(new BoxLayout(contenu, BoxLayout.Y_AXIS));

        JLabel titre = new JLabel("\uD83D\uDC64 Mon abonnement actuel :", SwingConstants.CENTER);
        titre.setFont(new Font("SansSerif", Font.BOLD, 22));
        titre.setAlignmentX(Component.CENTER_ALIGNMENT);
        contenu.add(titre);

        abonnementActuelLabel = new JLabel();
        abonnementActuelLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));
        abonnementActuelLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        abonnementActuelLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 30, 0));
        updateAbonnementLabel();
        contenu.add(abonnementActuelLabel);

        JLabel souscrireTitre = new JLabel("\u2728 Souscrire à un nouvel abonnement :", SwingConstants.CENTER);
        souscrireTitre.setFont(new Font("SansSerif", Font.BOLD, 20));
        souscrireTitre.setAlignmentX(Component.CENTER_ALIGNMENT);
        contenu.add(souscrireTitre);

        for (String offre : options) {
            JButton btn = new JButton(offre);
            btn.setMaximumSize(new Dimension(200, 40));
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.addActionListener(e -> souscrireAbonnement(offre));
            contenu.add(Box.createRigidArea(new Dimension(0, 10)));
            contenu.add(btn);
        }

        add(contenu, BorderLayout.CENTER);
    }

    private void updateAbonnementLabel() {
        if (client.getAbonnement() == null) {
            abonnementActuelLabel.setText("\uD83D\uDCC4 Aucun abonnement en cours.");
        } else {
            abonnementActuelLabel.setText("\uD83D\uDCC4 " + client.getAbonnement());
        }
    }

    private void souscrireAbonnement(String offre) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Confirmer votre souscription à : " + offre + " ?",
                "Confirmation",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            client.setAbonnement(offre);
            clientDAO.updateAbonnement(client);
            updateAbonnementLabel();
            JOptionPane.showMessageDialog(this, "✅ Abonnement " + offre + " activé avec succès !");
        }
    }
}

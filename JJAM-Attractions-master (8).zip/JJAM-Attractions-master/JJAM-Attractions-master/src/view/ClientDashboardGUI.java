package view;

import model.Client;
import javax.swing.*;
import java.awt.*;

public class ClientDashboardGUI extends JFrame {
    private Client client;
    private CardLayout cardLayout;
    private JPanel cardPanel;

    public ClientDashboardGUI(Client client) {
        this.client = client;
        initUI();
    }

    private void initUI() {
        setTitle("Espace Client - Bienvenue " + (client != null ? client.getNom() : ""));
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel menuPanel = new JPanel(new GridLayout(0, 1, 10, 10));

        JButton reservationBtn = new JButton("Réserver");
        JButton historiqueBtn = new JButton("Mes Réservations");
        JButton profilBtn = new JButton("Mon Profil");
        JButton goldenRoueBtn = new JButton("Golden Roue");
        JButton abonnementsBtn = new JButton("Mes Abonnements");
        JButton deconnexionBtn = new JButton("Déconnexion");

        menuPanel.add(reservationBtn);
        menuPanel.add(historiqueBtn);
        menuPanel.add(profilBtn);
        menuPanel.add(goldenRoueBtn);
        menuPanel.add(abonnementsBtn);
        menuPanel.add(deconnexionBtn);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        cardPanel.add(new ProfileGUI(client), "Profil");
        cardPanel.add(new HistoriqueGUI(client), "Historique");
        cardPanel.add(new GoldenRoueGUI(client), "GoldenRoue");
        cardPanel.add(new PromotionGUI(client), "Promotion");
        cardPanel.add(new MesAbonnementsPanel(client), "Abonnements");

        add(menuPanel, BorderLayout.WEST);
        add(cardPanel, BorderLayout.CENTER);

        reservationBtn.addActionListener(e -> {
            new ChoixParcGUI(client).setVisible(true);
        });

        historiqueBtn.addActionListener(e -> cardLayout.show(cardPanel, "Historique"));
        profilBtn.addActionListener(e -> cardLayout.show(cardPanel, "Profil"));
        goldenRoueBtn.addActionListener(e -> cardLayout.show(cardPanel, "GoldenRoue"));
        abonnementsBtn.addActionListener(e -> cardLayout.show(cardPanel, "Abonnements"));

        deconnexionBtn.addActionListener(e -> {
            new MenuPrincipal().setVisible(true);
            dispose();
        });

        setVisible(true);
    }
}

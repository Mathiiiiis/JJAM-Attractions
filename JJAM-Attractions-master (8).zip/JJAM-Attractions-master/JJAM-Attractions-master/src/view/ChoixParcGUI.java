package view;

import controller.ReservationController;
import dao.ParcDAOInterface;
import dao.ParcDAOImpl;
import model.Parc;
import model.Attraction;
import model.Client;
import utils.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class ChoixParcGUI extends JFrame {
    private JPanel mainPanel;
    private JButton continuerButton;
    private JPanel parcsPanel;
    private List<Parc> parcsSelectionnes = new ArrayList<>();
    private JLabel messagePromoLabel; // ✅ Ajout du message promo dynamique

    private Client clientConnecte;

    public ChoixParcGUI(Client client) {
        this.clientConnecte = client;
        setTitle("Sélection du Parc");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);
        setLocationRelativeTo(null);

        mainPanel = new JPanel(new BorderLayout());

        // 🆕 Partie du haut : explication des remises
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));

        JLabel introLabel = new JLabel("<html><center><b>Sélectionnez 1 ou plusieurs parcs.</b><br>Plus vous choisissez de parcs, plus vous bénéficiez d'une remise sur le prix total du ticket :</center></html>", SwingConstants.CENTER);
        introLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        introLabel.setAlignmentX(Component.CENTER_ALIGNMENT);



        messagePromoLabel = new JLabel("Sélectionnez vos parcs pour profiter des offres spéciales !", SwingConstants.CENTER);
        messagePromoLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        messagePromoLabel.setForeground(new Color(0, 102, 204));
        messagePromoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        topPanel.add(introLabel);

        topPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        topPanel.add(messagePromoLabel);
        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        mainPanel.add(topPanel, BorderLayout.NORTH);

        parcsPanel = new JPanel();
        parcsPanel.setLayout(new BoxLayout(parcsPanel, BoxLayout.Y_AXIS));
        mainPanel.add(new JScrollPane(parcsPanel), BorderLayout.CENTER);

        continuerButton = new JButton("Continuer");
        continuerButton.setEnabled(false);
        mainPanel.add(continuerButton, BorderLayout.SOUTH);

        add(mainPanel);

        loadParcs();

        continuerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!parcsSelectionnes.isEmpty()) {
                    new ChoixBilletsGUI(parcsSelectionnes, clientConnecte);
                    dispose();
                }
            }
        });

        setVisible(true);
    }

    private void loadParcs() {
        try (Connection conn = DBConnection.getConnection()) {
            ParcDAOInterface parcDAO = new ParcDAOImpl(conn);
            List<Parc> parcs = parcDAO.getAllParcsWithAttractions();

            for (Parc parc : parcs) {
                JPanel parcPanel = createParcPanel(parc);
                parcsPanel.add(parcPanel);
                parcsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            }

            revalidate();
            repaint();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des parcs", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createParcPanel(Parc parc) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        panel.setMaximumSize(new Dimension(700, 120));
        panel.setBackground(Color.WHITE);

        JCheckBox checkBox = new JCheckBox(parc.getNom() + " - Prix d'entrée : " + parc.getPrixEntree() + " €");
        panel.add(checkBox, BorderLayout.NORTH);

        JTextArea attractionsArea = new JTextArea();
        attractionsArea.setEditable(false);
        StringBuilder sb = new StringBuilder();
        for (Attraction attraction : parc.getAttractions()) {
            sb.append("- ").append(attraction.getNom()).append("\n");
        }
        attractionsArea.setText(sb.toString());
        JScrollPane scrollPane = new JScrollPane(attractionsArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        checkBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkBox.isSelected()) {
                    parcsSelectionnes.add(parc);
                } else {
                    parcsSelectionnes.remove(parc);
                }
                continuerButton.setEnabled(!parcsSelectionnes.isEmpty());
                updateSelectionVisual();
                updateMessagePromo();
            }
        });

        return panel;
    }

    private void updateSelectionVisual() {
        for (Component comp : parcsPanel.getComponents()) {
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                boolean isSelected = false;
                for (Component inner : panel.getComponents()) {
                    if (inner instanceof JCheckBox) {
                        isSelected = ((JCheckBox) inner).isSelected();
                        break;
                    }
                }
                if (isSelected) {
                    panel.setBackground(new Color(173, 216, 230)); // Bleu clair sélectionné
                } else {
                    panel.setBackground(Color.WHITE);
                }
            }
        }
    }

    private void updateMessagePromo() {
        int count = parcsSelectionnes.size();
        switch (count) {
            case 1 -> messagePromoLabel.setText("Ajoutez 1 parc et obtenez 10% de remise sur le prix du ticket !");
            case 2 -> messagePromoLabel.setText("Ajoutez 1 parc et obtenez 30% de remise sur le prix du ticket !");
            case 3 -> messagePromoLabel.setText("Ajoutez 1 parc et obtenez 40% de remise sur le prix du ticket !");
            case 4 -> messagePromoLabel.setText(" vous avez éconoisez 40% de remise sur le prix du ticket !");
            default -> messagePromoLabel.setText("Sélectionnez vos parcs pour profiter des offres spéciales !");
        }
    }
} // 🆕 Cette accolade manquait !!

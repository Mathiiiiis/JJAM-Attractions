package view;

import dao.ReservationDAO;
import model.Client;
import model.Reservation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class HistoriqueGUI extends JPanel {
    private Client client;
    private JTable table;
    private ReservationDAO reservationDAO;

    public HistoriqueGUI(Client client) {
        this.client = client;
        this.reservationDAO = new ReservationDAO();

        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("📋 Mon Historique de Réservations", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 26));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(titleLabel, BorderLayout.NORTH);

        table = new JTable();
        table.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadHistorique();
    }

    private void loadHistorique() {
        // 🔥 Corrigé : on utilise getCommandesByClientId au lieu de getReservationsByClientId
        List<Reservation> reservations = reservationDAO.getCommandesByClientId(client.getId());
        String[] columnNames = {"Date de Réservation", "Parc", "Nombre de Tickets"};

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (Reservation r : reservations) {
            model.addRow(new Object[]{
                    r.getDate().toString(),
                    r.getParcNom(),
                    r.getNombreTickets()
            });
        }
        table.setModel(model);
    }
}

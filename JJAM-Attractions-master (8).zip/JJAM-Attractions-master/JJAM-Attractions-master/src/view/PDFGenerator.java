package view;

import dao.ReservationDAO;
import model.Client;
import model.Parc;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class PDFGenerator {

    public static void generateFacturePDF(Client client, List<TicketPanel> billets, List<Parc> parcsChoisis, double total) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 20);
            contentStream.newLineAtOffset(50, 750);
            contentStream.showText("FACTURE - Parc Attractions");
            contentStream.endText();

            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.newLineAtOffset(50, 700);
            contentStream.showText("Client : " + client.getNom());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Email : " + client.getEmail());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("-------------------------------------------");

            double totalGeneral = 0;

            for (TicketPanel billet : billets) {
                double prix = calculerPrixAvecReductions(billet, parcsChoisis);
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText(billet.getNom() + " : " + String.format("%.2f", prix) + " €");
                totalGeneral += prix;
            }

            contentStream.newLineAtOffset(0, -30);
            contentStream.showText("TOTAL : " + String.format("%.2f", totalGeneral) + " €");
            contentStream.endText();

            contentStream.close();

            document.save("Facture_" + client.getNom() + ".pdf");
            Desktop.getDesktop().open(new File("Facture_" + client.getNom() + ".pdf"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void generateBilletsPDF(Client client, List<TicketPanel> billets, List<Parc> parcsChoisis) {
        try (PDDocument document = new PDDocument()) {
            for (TicketPanel billet : billets) {
                PDPage page = new PDPage(PDRectangle.A6);
                document.addPage(page);

                PDPageContentStream contentStream = new PDPageContentStream(document, page);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
                contentStream.newLineAtOffset(30, 400);
                contentStream.showText("🎟️ Billet d'Entrée");
                contentStream.newLineAtOffset(0, -30);
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.showText("Nom : " + billet.getNom());
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Profil : " + billet.getProfil());
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Date : Aujourd'hui");
                contentStream.newLineAtOffset(0, -20);

                for (Parc parc : parcsChoisis) {
                    contentStream.showText("- Parc : " + parc.getNom());
                    contentStream.newLineAtOffset(0, -20);
                }

                contentStream.endText();
                contentStream.close();
            }

            document.save("Billets_" + client.getNom() + ".pdf");
            Desktop.getDesktop().open(new File("Billets_" + client.getNom() + ".pdf"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static double calculerPrixAvecReductions(TicketPanel billet, List<Parc> parcsChoisis) {
        double prixTotal = 0;
        for (Parc parc : parcsChoisis) {
            prixTotal += parc.getPrixEntree();
        }

        int nbParcs = parcsChoisis.size();
        if (nbParcs == 2) prixTotal *= 0.9;
        if (nbParcs == 3) prixTotal *= 0.7;
        if (nbParcs == 4) prixTotal *= 0.6;

        if (billet.getProfil().equalsIgnoreCase("ENFANT")) {
            prixTotal *= 0.5;
        } else if (billet.getProfil().equalsIgnoreCase("SENIOR")) {
            prixTotal *= 0.7;
        }

        if (billet.isFastPassSelected()) {
            prixTotal += prixTotal * 0.6;
        }

        if (billet.getClient() != null) {
            ReservationDAO reservationDAO = new ReservationDAO();
            int nbCommandes = reservationDAO.getNombreCommandesByClientId(billet.getClient().getId()) + 1;

            if (nbCommandes >= 1 && nbCommandes < 5) {
                prixTotal *= 0.95;
            } else if (nbCommandes >= 5 && nbCommandes < 10) {
                prixTotal *= 0.90;
            } else if (nbCommandes >= 10) {
                prixTotal *= 0.85;
            }
        }

        return prixTotal;
    }
}

package view;

import model.Client;
import model.Parc;
import view.TicketPanel;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PageConfirmationReservationGUI extends JFrame {
    private Client client;
    private List<TicketPanel> billets;
    private List<Parc> parcsChoisis;
    private double totalFinal;

    public PageConfirmationReservationGUI(Client client, List<TicketPanel> billets, List<Parc> parcsChoisis, double totalFinal) {
        this.client = client;
        this.billets = billets;
        this.parcsChoisis = parcsChoisis;
        this.totalFinal = totalFinal;

        setTitle("Confirmation Réservation");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();
        setVisible(true);
    }

    private void initUI() {
        setLayout(new BorderLayout());

        JLabel confirmationLabel = new JLabel("<html><center>🎉 Votre réservation est confirmée !<br>Merci pour votre confiance.</center></html>", SwingConstants.CENTER);
        confirmationLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        confirmationLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(confirmationLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));

        JButton factureButton = new JButton("📄 Télécharger la facture");
        JButton ticketsButton = new JButton("🎟️ Télécharger les billets");

        factureButton.addActionListener(e -> {
            PDFGenerator.generateFacturePDF(client, billets, parcsChoisis, totalFinal);
            JOptionPane.showMessageDialog(this, "Facture téléchargée !");
        });

        ticketsButton.addActionListener(e -> {
            PDFGenerator.generateBilletsPDF(client, billets, parcsChoisis);
            JOptionPane.showMessageDialog(this, "Billets téléchargés !");
        });

        buttonPanel.add(factureButton);
        buttonPanel.add(ticketsButton);

        add(buttonPanel, BorderLayout.CENTER);
    }
}

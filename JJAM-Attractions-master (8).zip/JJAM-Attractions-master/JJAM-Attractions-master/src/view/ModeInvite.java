package view;

import model.Parc;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;

public class ModeInvite extends JFrame {

    public ModeInvite(List<Parc> parcsSelectionnes) {
        setTitle("Mode Invité - Billets");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 10, 10));

        JLabel label = new JLabel("Bienvenue en mode invité !", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 20));
        panel.add(label);

        JButton continuerBtn = new JButton("Continuer la réservation ➡️");
        continuerBtn.addActionListener(e -> {
            List<TicketPanel> billets = new ArrayList<>();

            // ✅ Correction : utiliser le nouveau constructeur avec 4 arguments
            for (Parc parc : parcsSelectionnes) {
                billets.add(new TicketPanel("Invité", "REGULIER", parc.getPrixEntree(), false));
            }

            int nombreBillets = billets.size();

            // ✅ Client null pour mode invité
            new PageCalendrier(parcsSelectionnes, nombreBillets, billets, null).setVisible(true);
            dispose();
        });
        panel.add(continuerBtn);

        JButton retourBtn = new JButton("Retour");
        retourBtn.addActionListener(e -> {
            new MenuPrincipal().setVisible(true);
            dispose();
        });
        panel.add(retourBtn);

        add(panel);
        setVisible(true);
    }
}

package view;

import dao.ReservationDAO;
import model.Client;
import model.Parc;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ResumeCommandeGUI extends JFrame {
    private Client client;
    private List<TicketPanel> billets;
    private List<Parc> parcsChoisis;

    public ResumeCommandeGUI(Client client, List<TicketPanel> billets, List<Parc> parcsChoisis) {
        this.client = client;
        this.billets = billets;
        this.parcsChoisis = parcsChoisis;

        setTitle("Résumé de la Commande");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();
        setVisible(true);
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new GridLayout(0, 3, 10, 10));
        mainPanel.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(mainPanel);
        add(scrollPane, BorderLayout.CENTER);

        double totalGlobal = 0;

        for (TicketPanel billet : billets) {
            JPanel ticket = creerTicketCaisse(billet);
            mainPanel.add(ticket);
            totalGlobal += calculerPrixBillet(billet);
        }

        JLabel totalLabel = new JLabel("💳 TOTAL À PAYER : " + String.format("%.2f", totalGlobal) + " €", SwingConstants.CENTER);
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        totalLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        add(totalLabel, BorderLayout.NORTH);

        JButton paiementBtn = new JButton("Accéder au paiement ➡️");
        paiementBtn.setFont(new Font("SansSerif", Font.BOLD, 18));
        paiementBtn.setBackground(new Color(0, 153, 0));
        paiementBtn.setForeground(Color.WHITE);
        paiementBtn.setFocusPainted(false);

        final double totalFinal = totalGlobal;

        paiementBtn.addActionListener(e -> {
            new EcranPaiementGUI(client, billets, parcsChoisis, totalFinal).setVisible(true);
            dispose();
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(paiementBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private JPanel creerTicketCaisse(TicketPanel billet) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.setBackground(Color.WHITE);
        panel.setPreferredSize(new Dimension(280, 350));
        panel.setMaximumSize(new Dimension(300, 350));

        JLabel nomLabel = new JLabel("👤 " + billet.getNom() + " - Profil : " + billet.getProfil());
        nomLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        panel.add(nomLabel);

        JLabel typeBilletLabel;
        if (billet.getClient() != null) {
            typeBilletLabel = new JLabel("✅ Billet connecté", SwingConstants.CENTER);
            typeBilletLabel.setForeground(new Color(0, 128, 0));
        } else {
            typeBilletLabel = new JLabel("🎟️ Billet invité", SwingConstants.CENTER);
            typeBilletLabel.setForeground(Color.GRAY);
        }
        typeBilletLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        panel.add(typeBilletLabel);

        panel.add(new JLabel(" "));

        double prixTotalParcs = 0;
        panel.add(new JLabel("🛝 Parcs choisis :"));
        for (Parc parc : parcsChoisis) {
            panel.add(new JLabel("- " + parc.getNom() + " : " + parc.getPrixEntree() + "€"));
            prixTotalParcs += parc.getPrixEntree();
        }

        panel.add(new JLabel(""));

        int nombreParcs = parcsChoisis.size();
        double reductionMultiParcs = 0.0;
        if (nombreParcs == 2) reductionMultiParcs = 0.10;
        else if (nombreParcs == 3) reductionMultiParcs = 0.30;
        else if (nombreParcs == 4) reductionMultiParcs = 0.40;

        double prixApresMulti = prixTotalParcs * (1 - reductionMultiParcs);

        double reductionProfil = 0;
        if (billet.getProfil().equalsIgnoreCase("ENFANT")) {
            reductionProfil = 0.5;
        } else if (billet.getProfil().equalsIgnoreCase("SENIOR")) {
            reductionProfil = 0.3;
        }

        double prixApresProfil = prixApresMulti * (1 - reductionProfil);

        boolean fastPass = billet.isFastPassSelected();
        double fastPassSupplement = 0;
        double prixApresFastPass = prixApresProfil;
        if (fastPass) {
            fastPassSupplement = prixApresProfil * 0.6;
            prixApresFastPass += fastPassSupplement;
        }

        double prixAvantFidelite = prixApresFastPass;
        double reductionFidelitePourcentage = 0;
        double reductionFideliteMontant = 0;

        if (billet.getClient() != null) {
            ReservationDAO reservationDAO = new ReservationDAO();
            int nbCommandes = reservationDAO.getNombreCommandesByClientId(billet.getClient().getId()) + 1;
            if (nbCommandes >= 1 && nbCommandes < 5) {
                reductionFidelitePourcentage = 0.05;
            } else if (nbCommandes >= 5 && nbCommandes < 10) {
                reductionFidelitePourcentage = 0.10;
            } else if (nbCommandes >= 10) {
                reductionFidelitePourcentage = 0.15;
            }
        }

        if (reductionFidelitePourcentage > 0) {
            reductionFideliteMontant = prixAvantFidelite * reductionFidelitePourcentage;
            prixAvantFidelite -= reductionFideliteMontant;
        }

        double prixAvantAbonnement = prixAvantFidelite;

        // 🆕 Gestion abonnement
        String abonnement = billet.getClient() != null ? billet.getClient().getAbonnement() : null;
        if (abonnement != null) {
            if (abonnement.equals("VIP")) {
                prixAvantAbonnement /= 2;
            } else if (abonnement.equals("PASS_ANNUEL")) {
                prixAvantAbonnement = 0;
            } else if (abonnement.equals("SUPER_VITESSE") && billet.isFastPassSelected()) {
                prixAvantAbonnement -= fastPassSupplement; // Retire le supplément FastPass si appliqué
            }
        }

        double prixFinal = prixAvantAbonnement;

        // Ajouts visuels
        panel.add(new JLabel("💸 Prix total parcs : " + String.format("%.2f", prixTotalParcs) + "€"));
        panel.add(new JLabel("➖ Réduction multi-parcs (" + (int) (reductionMultiParcs * 100) + "%) : -" + String.format("%.2f", prixTotalParcs * reductionMultiParcs) + "€"));
        panel.add(new JLabel("➖ Réduction profil (" + (int) (reductionProfil * 100) + "%) : -" + String.format("%.2f", prixApresMulti * reductionProfil) + "€"));
        if (fastPass) {
            panel.add(new JLabel("🚀 Fast Pass (+60%) : +" + String.format("%.2f", fastPassSupplement) + "€"));
        } else {
            panel.add(new JLabel("🚀 Fast Pass : Non ajouté"));
        }

        if (reductionFidelitePourcentage > 0) {
            panel.add(new JLabel("🎟️ Réduction fidélité (" + (int) (reductionFidelitePourcentage * 100) + "%) : -" + String.format("%.2f", reductionFideliteMontant) + "€"));
        }

        if (abonnement != null) {
            if (abonnement.equals("VIP")) {
                panel.add(new JLabel("👑 Réduction VIP (-50%)"));
            } else if (abonnement.equals("PASS_ANNUEL")) {
                panel.add(new JLabel("📅 Pass Annuel (100%)"));
            } else if (abonnement.equals("SUPER_VITESSE")) {
                panel.add(new JLabel("⚡ Super Vitesse (FastPass annulé)"));
            }
        }

        panel.add(new JLabel(" "));
        panel.add(new JLabel("💳 TOTAL billet : " + String.format("%.2f", prixFinal) + " €"));
        panel.add(new JLabel(" "));

        return panel;
    }

    private double calculerPrixBillet(TicketPanel billet) {
        double prixTotalParcs = 0;
        for (Parc parc : parcsChoisis) {
            prixTotalParcs += parc.getPrixEntree();
        }

        int nombreParcs = parcsChoisis.size();
        double reductionMultiParcs = 0;
        if (nombreParcs == 2) reductionMultiParcs = 0.10;
        if (nombreParcs == 3) reductionMultiParcs = 0.30;
        if (nombreParcs == 4) reductionMultiParcs = 0.40;

        double prixApresMulti = prixTotalParcs * (1 - reductionMultiParcs);

        double reductionProfil = 0;
        if (billet.getProfil().equalsIgnoreCase("ENFANT")) {
            reductionProfil = 0.5;
        } else if (billet.getProfil().equalsIgnoreCase("SENIOR")) {
            reductionProfil = 0.3;
        }

        double prixApresProfil = prixApresMulti * (1 - reductionProfil);

        double prixApresFastPass = prixApresProfil;
        if (billet.isFastPassSelected()) {
            prixApresFastPass += prixApresProfil * 0.6;
        }

        double prixAvantFidelite = prixApresFastPass;

        if (billet.getClient() != null) {
            ReservationDAO reservationDAO = new ReservationDAO();
            int nbCommandes = reservationDAO.getNombreCommandesByClientId(billet.getClient().getId()) + 1;
            if (nbCommandes >= 1 && nbCommandes < 5) {
                prixAvantFidelite *= 0.95;
            } else if (nbCommandes >= 5 && nbCommandes < 10) {
                prixAvantFidelite *= 0.90;
            } else if (nbCommandes >= 10) {
                prixAvantFidelite *= 0.85;
            }

            String abonnement = billet.getClient().getAbonnement();
            if (abonnement != null) {
                if (abonnement.equals("VIP")) {
                    prixAvantFidelite /= 2;
                } else if (abonnement.equals("PASS_ANNUEL")) {
                    prixAvantFidelite = 0;
                } else if (abonnement.equals("SUPER_VITESSE") && billet.isFastPassSelected()) {
                    prixAvantFidelite -= prixApresProfil * 0.6;
                }
            }
        }

        return prixAvantFidelite;
    }
}
